</div> <!-- end .container -->

<footer>
    &copy; <?= date('Y') ?> By TTA.
</footer>

</body>
</html>
