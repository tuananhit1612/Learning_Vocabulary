<?php
require_once 'app/models/Word.php';

class HomeController {
    public function index() {
       require 'app/views/home/index.php';
    }
}
